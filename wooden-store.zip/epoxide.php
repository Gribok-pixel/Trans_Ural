<div class="container">
    <div class="epoxide">
        <!-- <img src="image/background.jpg" alt="epoxide"> -->
    </div>
</div>